package com.example.memorials.dto;

public class ProductDto {
    public Long id;
    public String name;
    public String description;
    public String category;
    public Double price;
    public java.util.List<String> imageKeys;
    public ProductDto() {}
}
