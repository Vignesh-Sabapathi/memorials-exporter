package com.example.memorials;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MemorialsApplication {
    public static void main(String[] args) {
        SpringApplication.run(MemorialsApplication.class, args);
    }
}
